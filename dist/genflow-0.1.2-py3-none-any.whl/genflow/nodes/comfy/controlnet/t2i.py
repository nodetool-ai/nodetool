from genflow.nodes.comfy.controlnet import PreprocessImage


class ColorPreprocessor(PreprocessImage):
    pass


class ShufflePreprocessor(PreprocessImage):
    pass
